sed -E '/william/s/kate |kate$/diana/3' $1
