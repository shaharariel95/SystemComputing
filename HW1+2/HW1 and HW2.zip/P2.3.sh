rm -r dirA/dir1/d1
