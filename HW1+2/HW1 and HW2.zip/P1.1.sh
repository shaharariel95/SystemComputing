echo -n "Enter first file name: "
read f1
echo -n "Enter second file name: "
read f2
echo Beginning of first file $f1
cat $f1
echo End of first file $f1
echo
echo This is the second file $f2
cat $f2 -n



