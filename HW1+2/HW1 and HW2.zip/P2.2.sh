cp -r dirA/d1 dirA/dir1
